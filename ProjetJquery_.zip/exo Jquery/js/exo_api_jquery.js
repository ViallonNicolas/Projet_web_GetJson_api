
/* Fonction slider haut de page avec la fonction animate*/	
$(function() {
    var i=0;
    slider();

   function slider() {
	  
        i=i+1;
	  
          
        var actual = '#img' + i;
		var img1 = '#img1' ;
		var img2 = '#img2' ;
		var img3 = '#img3' ;
		var img4 = '#img4' ;
		var img5 = '#img5' ;
		var img6 = '#img6' ;
		var img7 = '#img7' ;
		var img8 = '#img8' ;
		var img9 = '#img9' ;
		var img10 = '#img10' ;
		
		
		$(actual).animate({marginLeft:"-=100vw",opacity :0.5},1500);	/*permet de faire defiler les images vers la gauche et la ramener à sa position initiale sans qu'on le voit*/
		$(actual).animate({marginLeft:"+=100vw",opacity:0},0);
		
		
	  
	 if (i==11){ 
			
			$(img10).animate({opacity:1},0);					/*une fois toutes les images défilées ont leur remet leur opacité à 1 et on recommence*/
			$(img9).animate({opacity:1},0);
			$(img8).animate({opacity:1},0);
			$(img7).animate({opacity:1},0);
			$(img6).animate({opacity:1},0);
			$(img5).animate({opacity:1},0);
			$(img4).animate({opacity:1},0);
			$(img3).animate({opacity:1},0);
			$(img2).animate({opacity:1},0);
			$(img1).animate({opacity:1},0);
			i=0; 
	 }
   }
	
    setInterval(slider,3000);				/* rappel de la fonction à 2s d'intervalle*/
  });
 

  
  
  
  /*SLIDER FADE IN FADE OUT*/
 /* $(function() {
    var i=0;
    slider();

   function slider() {
	  
      i=i+1;
      if (i==1) last = '#img10'					 rotation des images
           else last = '#img' + (i-1);
      var actual = '#img' + i;
	  
		/*$(last).fadeOut(2000);			/* effet de disparition
		
		/*$(actual).fadeIn(2000);
	  
      if (i==10) i=0;          
      }

    setInterval(slider,2000);				/* rappel de la fonction à 3s d'intervalle
  });*/

function clickgta() {
	$.get('https://api.rawg.io/api/games/3498', function( data ) {							/*fonction pour afficher les données de gta*/
		
    $('#titre_2').html("Titre : " + data.name);
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clicktwd() {
	$.get('https://api.rawg.io/api/games/23027', function( data ) {							/*fonction pour afficher les données de twd*/
    $('#titre_2').html("Titre : " + data.name);
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clicksmb() {
	$.get('https://api.rawg.io/api/games/3144', function( data ) {
    $('#titre_2').html("Titre : " + data.name);												/*fonction pour afficher les données de Super meat boy*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clickmin() {
	$.get('https://api.rawg.io/api/games/minecraft', function( data ) {
    $('#titre_2').html("Titre : " + data.name);													/*fonction pour afficher les données de Minecraft*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clickfifa() {
	$.get('https://api.rawg.io/api/games/fifa-20', function( data ) {
    $('#titre_2').html("Titre : " + data.name);														/*fonction pour afficher les données de Fifa*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clickrdr() {
	$.get('https://api.rawg.io/api/games/red-dead-redemption-2', function( data ) {
    $('#titre_2').html("Titre : " + data.name);														/*fonction pour afficher les données de Fifa*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};

function clickrdr() {
	$.get('https://api.rawg.io/api/games/red-dead-redemption-2', function( data ) {
    $('#titre_2').html("Titre : " + data.name);														/*fonction pour afficher les données de Red dead Redemption 2*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};


function clickcs() {
	$.get('https://api.rawg.io/api/games/counter-strike-global-offensive', function( data ) {
    $('#titre_2').html("Titre : " + data.name);														/*fonction pour afficher les données de Red dead Redemption 2*/
	$('#shot').html("<img class=\"shots\" src=\"" + data.background_image + "\">");
	$('#description').html("Description : " + data.description);
	$('#note').html("Note : " + data.rating);
});

 
};


